﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Đăng nhập hệ thống</title>
<link rel='stylesheet'  href='/admin/css/login.css' type='text/css' media='all' />
</head>

<body style="background: url('/admin/img/bg.jpg');" class="login login-action-login wp-core-ui  locale-vi" onload="onload();">
	<div id="login">
		<h2 style="text-align:center;margin-left: -60px;"><a href="/" title="Binh Minh Store"><img src="/images/logo2.png"/></a></h2>
<form action="act-login.php" method="post">
	<p>
		<label>Tên tài khoản<br />
		<input type="text" name="user" class="input" /></label>
	</p>
	<p>
		<label>Mật khẩu<br />
		<input type="password" name="pass"  class="input" /></label>
	</p>
		<p class="submit">
		<input type="submit" name="submit" style="background: #1e8cbe;border-color: #0074a2;height: 30px;line-height: 28px;padding: 0 12px 2px;color: #fff;" value="Đăng nhập" />
		<p id="nav"><a href="#" title="Tạo mật khẩu mới">Tạo tài khoản</a> |
	<a href="#" title="Tạo mật khẩu mới">Quên mật khẩu</a>
</p>

	<p id="backtoblog"><a href="/" title="Quên?">&larr; Quay lại Binh Minh Computer</a></p>
	</p>
</form>


	
	</div>

</body>
</html>


