﻿<table  border="0" cellspacing="0" cellpadding="0">
<tr height="100">
	  <td style="float:left;  margin-left: 30px;"><a href="/" title="Trang chủ" target="_blank"><img width="250" height="94" src="/images/logo.png" /></a></td>
	  <td style="float:right;margin-left:450px;margin-top: 10px;">
		<img src="/admin/img/user.png" style="margin:8px;width:60px;height:60px;" />
		<p style=" margin-top: 22px;float:right"> <?php echo "Xin chào, ".$_SESSION['useradmin']; ?><br />
        <a href="../admin/?m=doi-mat-khau">Đổi mật khẩu</a> | <a href="../admin/logout.php">Thoát</a> </p>
	</td>
</tr>
</table>   