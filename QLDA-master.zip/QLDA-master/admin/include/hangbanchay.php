﻿<table width="735" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="5" class="tieude" align="center">DANH SÁCH MẶT HÀNG BÁN CHẠY</td>
  </tr>  
  <tr height="30" class="dau">        
        <td align="center" width="150" style="border-right:1px solid #333"><strong>Tên sản phẩm</strong></td>
        <td align="center" width="150" style="border-right:1px solid #333"><strong>Giá</strong></td>
        <td align="center" width="135" style="border-right:1px solid #333"><strong>Số lượng</strong></td>
        <td align="center" width="150" style="border-right:1px solid #333"><strong>Hình ảnh</strong></td>
         <td align="center" width="150" style="border-right:1px solid #333"><strong>Tổng tiền</strong></td>
  </tr>  
  
  <tr>
  	<td align="center" colspan="5" height="30"><strong>Chức năng đang hoàn thiện</strong></td>
  </tr>


</table>