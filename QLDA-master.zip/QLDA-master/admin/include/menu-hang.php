﻿<table width="215" border="0" cellspacing="0" cellpadding="0">
  <tr>
   <td class="menu" height="30"><div align="left">QUẢN LÝ HÀNG:</div></td>
  </tr>
  <tr>
   <td height="50" style="padding-left:20px">
   <div align="left">
   <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"/> <a href="../admin/?m=hang&page=them-hang" class="admin-menu-left"> Thêm hàng mới</a><br>
	<div style="height:10px"></div>
   <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"/> <a href="../admin/?m=hang&page=ds-hang" class="admin-menu-left"> Danh sách hàng</a>    
    </div>
   </td>   
  </tr>
  <tr>
  	<td><?php include "include/menu-tree.php"; ?></td>
  </tr>
</table>

