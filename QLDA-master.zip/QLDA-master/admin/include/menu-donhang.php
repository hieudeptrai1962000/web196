﻿<div style="margin-bottom:10px;">
<table width="215" border="0" cellspacing="0" cellpadding="0">
  <tr>
   <td class="menu" height="30"><div align="left">QUẢN LÝ ĐƠN HÀNG</div></td>
  </tr>
 
  <tr>
   <td height="70" style="padding-left:20px">
  <div align="left">
    <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"/> <a href="../admin/?m=dh&page=don-hang" class="admin-menu-left">Danh sách đơn đặt hàng</a> 
   	<div style="height:10px"></div>
	<img src="/images/orange-circle-list.png" style="margin: 2px 4px;"/> <a href="../admin/?m=dh&page=don-hang-ok" class="admin-menu-left">Danh sách đơn hàng đã mua</a>
	</div>
    </td>
  </tr>
  
</table>
</div>