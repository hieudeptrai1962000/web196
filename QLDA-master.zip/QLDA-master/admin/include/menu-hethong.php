﻿<table width="215" border="0" cellspacing="0" cellpadding="0">
  
  <tr>
  	<td height="30" class="menu" >
      <strong>Hệ thống</strong></td>
  </tr>
  <tr>
   <td height="60" style="padding-left:20px">
  <div align="left">
   <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"> <a href="#"  onclick="return ht();" class="admin-menu-left"> Giới thiệu website</a> 
   	<div style="height:10px"></div>
   <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"> <a href="/admin/?m=he-thong&page=cau-hinh" class="admin-menu-left"> Cấu hình hệ thống</a>
	</div>
    </td>
  </tr>
    <tr>
  	<td class="menu"  height="30">
      <strong> Quản lý tin tức</strong></td>
  </tr>
  <tr>
   <td height="50" style="padding-left:20px">
  <div align="left">
   <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"> <a href="#"  onclick="return ht();"  class="admin-menu-left"> Thêm tin tức mới</a> 
   	<div style="height:10px"></div>
   <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"> <a href="#"  onclick="return ht();" class="admin-menu-left"> Danh sách tin tức</a>
	</div>
    </td>
  </tr> 
   <tr>
   <td class="menu" style="padding-left:20px" height="25"><strong>Quản lý khuyến mại</strong></td>
   </tr>
  <tr> 
	   <td height="50" style="padding-left:20px">
  <div align="left">
   <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"> <a href="#"  onclick="return ht();" class="admin-menu-left"> Thêm tin khuyến mại</a> 
   	<div style="height:10px"></div>
   <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"> <a href="#"  onclick="return ht();" class="admin-menu-left"> Danh sách khuyến mại</a>
	</div>
    </td>
  </tr>
  
  
  
  <tr>
   <td class="menu" style="padding-left:20px" height="25"><strong>Quản lý tuyển dụng</strong></td>
   </tr>
  <tr> 
	   <td height="50" style="padding-left:20px">
  <div align="left">
   <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"> <a href="#"  onclick="return ht();" class="admin-menu-left"> Thêm tin tuyển dụng</a> 
   	<div style="height:10px"></div>
   <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"> <a href="#"  onclick="return ht();" class="admin-menu-left"> Danh sách tuyển dụng</a>
	</div>
    </td>
  </tr>
  
  <!---->
  
  
  
</table>