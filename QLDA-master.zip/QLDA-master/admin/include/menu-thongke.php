﻿<script>
alert("Chức năng đang hoàn thiện");
</script>
<div style="margin-bottom:10px; ">
<table width="215" border="0" cellspacing="0" cellpadding="0">
  <tr>
   <td class="menu" height="30"><div align="left">Báo cáo thống kê</div></td>
  </tr>
 
  <tr>
   <td height="70" style="padding-left:20px">
  <div align="left">
    <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"/> <a href="../admin/?m=mtk&page=doanh-thu" class="admin-menu-left">Thống kê doanh thu</a>
	<div style="height:10px"></div>
    <img src="/images/orange-circle-list.png" style="margin: 2px 4px;"/>  <a href="../admin/?m=mtk&page=hang-ban-chay" class="admin-menu-left">Mặt hàng bán chạy</a> 

	</div>
    </td>
  </tr>
  
</table>
</div>