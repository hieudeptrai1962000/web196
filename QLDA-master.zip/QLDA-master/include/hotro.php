<div align="center" class="full" id="cart-content" style="  margin-top: -20px;line-height:30px; padding:5px;">
	<div style="background: #16a085;font-size: 14px;text-transform: uppercase; color: #fff;line-height: 40px; width: 980px;position: relative;font-weight:bold">HỖ TRỢ KHÁCH HÀNG
	</div>
<div align="left" style="padding: 15px; box-shadow: 0px 0px 5px rgba(50, 50, 50, 0.5);font-size: 15px;font-family: arial;" >
<div style="text-align: center;"><span style="color: #d4340c; font-size: large;"><strong>HƯỚNG DẪN MUA HÀNG</strong></span></div>


<span style="color: red;"><strong>Đối với khách hàng đã đăng ký tài khoản:</strong></span><br />
<strong>» Bước 1:</strong> Đăng nhập vào website.<br />
<strong>» Bước 2:</strong> Lựa chọn Hàng trên web và cho vào giỏ hàng.<br />
<strong>» Bước 3:</strong> Nhấn vào nút "Đặt hàng" để gửi đơn đặt hàng cho công ty.<br />
<br />
<span style="color: red;"><strong>Đối với khách hàng chưa đăng ký tài khoản:</strong></span><br />
<strong>» Bước 1:</strong> Lựa chọn Hàng trên web và cho vào giỏ hàng.<br />
<strong>» Bước 2:</strong> Nhấn vào nút "Đặt hàng".<br />
<strong>» Bước 3:</strong> Quý khách nhập những thông tin cần thiết để chúng tôi có thể liên hệ.<br />
<span style="color: red;"><strong><br />Nhân viên của chúng tôi sẽ liên lạc với bạn trong vòng 24h để xác nhận đơn hàng và địa chỉ nhận hàng.&nbsp;</strong></span><br />
<span style="color: red;"><strong>Hàng sẽ được chuyển đến tận nơi khách hàng yêu cầu từ 1 đến 7 ngày và hoàn toàn miễn phí cước vận chuyển. </strong></span><br />
<br />

<br />


<div style="text-align: center;"><span style="color: #d4340c; font-size: large;">
<strong>CÁC PHƯƠNG THỨC THANH TOÁN</strong></span></div>
<p><span style="font-size: medium; color: #ff6600;"><strong>1. THANH TOÁN BẰNG TIỀN MẶT</strong></span></p>
Quý khách hàng có thể thanh toán bằng tiền mặt tại hệ thống siêu thị BMC trên toàn quốc  hoặc Nhân viên giao nhận trước khi nhận hàng (đối với trường hợp giao hàng tận nơi).
<p><span style="font-size: medium; color: #ff6600;"><strong>2. THANH TOÁN BẰNG CHUYỂN KHOẢN</strong></span></p>
Quý khách hàng có thể đến ngân hàng, máy ATM, mobile banking (sms banking) hoặc internet banking để chuyển khoản cho chúng tôi theo tài khoản ngân hàng sau:
<BR />

1. Ngân hàng Sacombank (SCB):<br />
        - Chủ tài khoản: <br />

        - Số tài khoản: <br />
        - Chi nhánh: <br />
2. Ngân hàng Á châu (SCB):<br />
        - Chủ tài khoản:<br />

        - Số tài khoản: <br />

        - Chi nhánh: <br />
		
3. Ngân hàng Vietcombank (VCB):<br />
        - Chủ tài khoản:<br />

        - Số tài khoản: <br />

        - Chi nhánh: <br />
<STRONG>Nội dung gửi tiền quý khách vui lòng ghi theo mẫu: Tên khách đặt hàng - Số điện thoại đặt hàng - Số hóa đơn</STRONG>

<p><span style="font-size: medium; color: #ff6600;"><strong>3. THANH TOÁN TRỰC TUYẾN</strong></span></p>
Quý khách hàng có thể thanh toán trực tuyến cho cho chúng tôi theo tài khoản sau:<br />
Bảo Kim: billing@binhminhcomputer.com<br />
Ngân lượng: billing@binhminhcomputer.com<br />
Paypal: billing@binhminhcomputer.com<br />

<br />
<div align="center"><strong><span style="color: #d4340c;">XIN CHÂN THÀNH CẢM ƠN QUÝ KHÁCH!</strong></div>


</div></div>