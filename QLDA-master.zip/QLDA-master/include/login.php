<div align="center" class="full" id="cart-content" style="  margin-top: -20px;line-height:25px; padding:5px;">
	<div style="margin-top:-5px;background: #16a085!important;font-size: 14px;text-transform: uppercase; color: #fff;line-height: 40px; width: 980px;position: relative;font-weight:bold">Khách hàng đăng nhập
	</div>
<div style="padding: 15px; box-shadow: 0px 0px 5px rgba(50, 50, 50, 0.5);font-size: 14px;font-family: arial;" align="center">	
	<form action="include/act-login.php" method="post">
		<table width="550" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td height="30"><div style="padding-center:70px">Tên đăng nhập: </div></td>
				<td> <input type="text" name="user" /></td>
			</tr>
			<tr>
				<td height="30"><div style="padding-center:70px">Mật khẩu: </div></td>
				<td>  <input type="password" name="pass"/></td>
			</tr>
			
			<tr>
				<td colspan="2" align="center" height="30"><br />
					<input type="submit" value="Đăng nhập" class="button">
					<input type="reset" value="Nhập lại" class="button" >
				<input type="hidden" name="act">
				<br />
				<div style="padding-top:10px; font-family:Tahoma; font-size:12px"> <a href="/?page=quen-mat-khau">&raquo; Quên mật khẩu </a>  <a href="/?page=dang-ky">&raquo; Tạo tài khoản</a></div>
				</td>
			<tr>
		</table>
	</form>
</div></div>