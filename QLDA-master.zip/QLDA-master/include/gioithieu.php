 <div class="clear"></div>
<div align="center" class="full" id="cart-content" style="  margin-top: -20px;line-height:30px; padding:5px;">
	<div style="background: #16a085;font-size: 14px;text-transform: uppercase; color: #fff;line-height: 40px; width: 980px;position: relative;font-weight:bold">Giới thiệu Bình Minh Computer
	</div>
<div align="left" style="padding: 15px; box-shadow: 0px 0px 5px rgba(50, 50, 50, 0.5);font-size: 15px;font-family: arial;" >
<img src="/images/orange-circle-list.png" style="margin: 2px 4px;">  Công ty Cổ Phần Bình Minh Computer (BMC)
<br />
<img src="/images/orange-circle-list.png" style="margin: 2px 4px;">   Tên giao dịch viết tắt: Bình Minh Co., Ltd
<br />
<img src="/images/orange-circle-list.png" style="margin: 2px 4px;">   Trụ sở chính:  Sóc Đăng, Đoan Hùng, Phú Thọ.
<br />
<img src="/images/orange-circle-list.png" style="margin: 2px 4px;">   Văn phòng GD:  Sóc Đăng, Đoan Hùng, Phú Thọ.
<br />
<img src="/images/orange-circle-list.png" style="margin: 2px 4px;">  Hotline: 1800.9999 - 0210.999.999<br />
<img src="/images/orange-circle-list.png" style="margin: 2px 4px;">  Email: hotro@binhminhcomputer.com<br /><img style="float:right" width="500" src="/images/bando.png" />
<img src="/images/orange-circle-list.png" style="margin: 2px 4px;">  Lĩnh vực hoạt động kinh doanh: Cung cấp sản phẩm máy tính, các phụ kiên máy tính, thiết bị kỹ thuật số.<br />

 Công ty Cổ Phần Bình Minh Computer (BMC) là một trong những doanh nghiệp hàng đầu hoạt động trong lĩnh vực kinh doanh các sản phẩm CNTT. Thành lập từ năm 2010 đến nay, công ty đã tạo được chỗ đứng vững chắc trên thị trường bán buôn, bán lẻ, trở thành thương hiệu quen thuộc và là đối tác tin cậy của nhiều bạn hàng trong nước và Quốc tế.
<br />
 Với hơn 4 năm hoạt động, công ty đã có một hệ thống khách hàng ổn định trải dài từ Bắc đến Nam. Luôn lấy yếu tố hài hòa về lợi ích làm nền tảng, lãnh đạo Công ty hiểu rằng, niềm tin của khách hàng về giá thành, chất lượng và dịch vụ là sự sống còn của Công ty. Do vậy, mọi hoạt động kinh doanh của Công ty luôn hướng tới mục tiêu tôn trọng và bảo đảm quyền lợi cho khách hàng, chinh phục khách hàng bằng chất lượng sản phẩm và dịch vụ tối ưu.
<br />
 BMC cũng mang lại cho các thành viên công ty một môi trường làm việc thân thiện, chuyên nghiệp và một công việc ổn định, hấp dẫn. Tất cả cán bộ, nhân viên hiện đang cộng tác và làm việc tại công ty đều có nghiệp vụ chuyên môn vững vàng, có trách nhiệm với công việc, giàu tính sáng tạo cùng với tinh thần làm việc đầy nhiệt huyết.


 </div>
 <div class="clear"></div>
</div>