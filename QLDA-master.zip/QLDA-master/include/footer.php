<div class="wrap-full regular-font" id="wrap-receive-mail">
    <div id="receive-mail" class="full">
        <div id="slogan" class="floatl">
			<div class="textwidget">BÌNH MINH COMPUTER - SIÊU THỊ MÁY TÍNH HÀNG ĐẦU VIỆT NAM</div>
		</div>
		<div id="social" class="floatr">
			<div class="textwidget">
				<div class="social-title floatl">TÌm chúng tôi trên : </div>
				<a class="fb" href="#"></a>
				<a class="gp" href="#"></a>
				<a class="tw" href="#"></a>
			</div>
		</div>
	</div>
<div class="clear"></div>
</div>
<div id="wrap-bottom-site" class="wrap-full">
    <div id="bottom-site" class="full regular-font">
        <div class="floatl col1">
			<div class="title">Siêu thị máy tính Binh Minh</div>
			<div class="textwidget">
			<p>Địa chỉ:  Sóc Đăng, Đoan Hùng, Phú Thọ.<br />
			Hotline:1800.9999<br />
			Email: hotro@binhminhcomputer.com<br />
			GPĐKKD số xxx do Sở KHĐT Phú Thọ cấp ngày xx/xx/yyyy
			</p>
			</div>
		</div>

        <div class="floatr col2">
            <span class="floatr"><img width="250" height="78" class="attachment-full" style="max-width: 100%;" src="/images/logo.png" /></span>
            <div class="clear"></div>
            <p>Copyright © 2015 <a href="/" rel="home">Bình Minh Computer</a>.</p>
			<p>Thiết kế bởi: Nhóm 11 HTTT K7 HAUI</p>
        </div>
        <div class="clear"></div>
    </div>
</div>
<img  style="bottom:0; right:0; position:fixed;" src="/images/support.png" />
<!--
<script type="text/javascript">
var __lc = {};
__lc.license = 5991791;

(function() {
	var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
	lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
})();
</script>-->