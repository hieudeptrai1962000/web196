﻿<div align="center" class="full" id="cart-content" style="  margin-top: -20px;line-height:25px; padding:5px;">
	<div style="margin-top:-15px;background: #16a085!important;font-size: 14px;text-transform: uppercase; color: #fff;line-height: 40px; width: 980px;position: relative;font-weight:bold">Tin tức
	</div>
	<div style="height:1000px;padding: 15px; box-shadow: 0px 0px 5px rgba(50, 50, 50, 0.5);font-size: 14px;font-family: arial;" align="center">	 
	ĐANG CẬP NHẬT
	<a href="#"><img src="/images/tin.png" /></a>
	</div>    		
</div>    
<div class="clear"></div>