<div align="center" class="full" id="cart-content" style="  margin-top: -20px;line-height:30px; padding:5px;">
	<div style="background: #16a085;font-size: 14px;text-transform: uppercase; color: #fff;line-height: 40px; width: 980px;position: relative;font-weight:bold">Thông tin khuyến mãi tại Bình Minh Computer
	</div>
<div align="left" style="padding: 15px; box-shadow: 0px 0px 5px rgba(50, 50, 50, 0.5);font-size: 15px;font-family: arial;" >
<a href="#" title="khuyến mãi"><img style="width:450px;padding:10px;" src="/images/khuyenmai/1.jpg" /></a>
<a href="#" title="khuyến mãi"><img style="width:450px;padding:10px;" src="/images/khuyenmai/2.jpg" /></a>
<a href="#" title="khuyến mãi"><img style="width:450px;padding:10px;" src="/images/khuyenmai/3.jpg" /></a>
<a href="#" title="khuyến mãi"><img style="width:450px;padding:10px;" src="/images/khuyenmai/4.jpg" /></a>
<a href="#" title="khuyến mãi"><img style="width:450px;padding:10px;" src="/images/khuyenmai/5.jpg" /></a>
<a href="#" title="khuyến mãi"><img style="width:450px;padding:10px;" src="/images/khuyenmai/6.jpg" /></a>
</div>
</div>
<div class="clear"></div>